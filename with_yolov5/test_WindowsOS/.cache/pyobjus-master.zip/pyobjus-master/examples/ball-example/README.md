pyobjus-ball
============

Example of using accelerometer to move ball on screen, with pyobjus and kivy-ios on iOS 
