__version__ = '1.2.2.dev0'
from .pyobjus import *
